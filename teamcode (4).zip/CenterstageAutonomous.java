// package org.firstinspires.ftc.teamcode;
// import org.firstinspires.ftc.teamcode.Base.AutoRobotStruct;
// import com.qualcomm.robotcore.hardware.DcMotor;
// import com.qualcomm.robotcore.hardware.Servo;
// import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
// 
// @Autonomous
// 
// public class CenterstageAutonomous extends AutoRobotStruct {
// 
//     public void runOpMode() {
//         initRunner();
//        
//         waitForStart();
//      
//                           
//        
//         int test = 1;
//             while (opModeIsActive()) {
//                 
//             
//                
//            scorePix();
//            sleep(10000);
//                 /*
//             if (test == 1) {
//             setDriverMotorPower(-0.20, -0.20, -0.20, -0.20, 4200);
//             setDriverMotorZero();
//             test = 0;
//             dragBlock.setPosition(0.05);
//             }
//             */
//             }
//             
//     }
// }